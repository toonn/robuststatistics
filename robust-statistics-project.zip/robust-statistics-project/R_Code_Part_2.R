################################################################
### PART 2 - BEGIN
################################################################

################################################################
### Define function dataX( n, nc1, nc2, nc12 ) which
### RETURNS a list containing a (nx2) matrix X
### nc1, nc2, nc12 being the number of contaminated values in
### the 1st,2nd and in both components respectively.
dataX = function( n, nc1=0, nc2=0, nc12=0 ){
    nclean = n - (nc1 + nc2 + nc12)
    Y = matrix( data=rnorm( n=2*nclean, mean=0, sd=1 ), ncol=2)
    Yout1 = matrix( c(rnorm( n=nc1, mean=10*sqrt(2), sd=0.1 ),
               rnorm( n=nc1, mean=0, sd=1 )), ncol=2 )
    Yout2 = matrix( c( rnorm( n=nc2, mean=0, sd=1 ),
               rnorm( n=nc2, mean=10*sqrt(2), sd=0.1 )),ncol=2)
    Yout12 = matrix( c( rnorm( n=nc12, mean=10*sqrt(2), sd=0.1),
               rnorm( n=nc12, mean=10*sqrt(2), sd=0.1 )),ncol=2)
    Y = rbind( Y, Yout1, Yout2, Yout12 )
    X = Y
    sample = sample( n )
    X[sample,] = Y
    # retrieve and store positions of various outlier groups
    # in matrix X:
    count = nclean
    clean = sample[ (1:count) ]
    ol1 = sample[ ((count+1):(count+nc1)) ]; count = count+nc1
    ol2 = sample[ ((count+1):(count+nc2)) ]; count = count+nc2
    ol12 = sample[ ((count+1):(count+nc12)) ]

    Xlist = list( X=X, clean=clean, ol1=ol1, ol2=ol2, ol12=ol12)    
}
### Check:
#Xlist = dataX( 50, 13, 13, 7 )
#Xlist
### Check counts and order of outliers in data matrix X in Xlist:
#Xlist$X[ c( Xlist$clean, Xlist$ol1, Xlist$ol2, Xlist$ol12 ),]
################################################################

################################################################
### Define function "huber(X)" which takes a data matrix X (nxp)
### and returns a corresponding huberized data matrix XH (nxp):
huber = function( X ){
    XH = matrix( 0, nrow=nrow(X), ncol=ncol(X) )
    cH = qnorm( p=0.975 )
    for( j in 1:ncol(X) ){ #evaluate XHj for a given column j
        medXj = median(X[,j])
        madXj = mad(X[,j], constant=1)
        c.v = ( X[,j] - medXj ) / madXj
        # evalutate xHij for each i within column j
        for( i in 1:nrow(X) ){ 
            if( c.v[i] < -cH ){
                XH[i,j] = medXj - cH*madXj
            } else if( c.v[i] <= cH ){
                XH[i,j] = X[i,j]
            } else
                XH[i,j] = medXj + cH*madXj
        }
    }
    XH
}
### check:
#huber( X )
################################################################

################################################################
### Define function "rXa()" which returns a vector of values
### representing theSD-outlyingness of the components of "X"
### with respect to direction "a":
rXa = function( X, a, h=FALSE){
    Y = X%*%a
    if( h ) YH = huber(X)%*%a else YH = Y
    n = nrow(X)
    p = ncol(X)
    beta = qnorm( p=0.5*( (n+p-1)/(2*n) + 1 ) )
    constant = 1 / beta
    mmad.YH = mad( YH, constant = constant ) # modified MAD
    abs( Y - median(YH) ) / mmad.YH
}
################################################################

################################################################
### Define function "SDout( X, k=1000, h=FALSE )" which
### RETURNS: SD-outlyingness for all n cases (p-variate) in
###          matrix X (nxp)
### ARGUMENTS: X is (nxp) data matrix; k is number of random
###            directions "a"; h determines whether
###            huberization is used (h=TRUE) or not (h=FALSE)
SDoutf = function( X, k=10000, h=FALSE ){
    rXmax = rep( 0 , nrow(X) )
    for( i in 1:k ){
        r.a = rnorm( n=ncol(X) )
        r.a = r.a / sqrt( sum( r.a^2 ) )
        rXmax = pmax( rXmax, rXa(X,r.a, h) )
    }
    rXmax
}
### Check:
### Generate list containing data matrix X and vectors with
### positions of contaminated cases:
Xlist = dataX( n=50, nc1=7, nc2=7, nc12=3 )
X = Xlist$X; clean = Xlist$clean; ol1 = Xlist$ol1;
               ol2 = Xlist$ol2; ol12 = Xlist$ol12
order = c( clean, ol1, ol2, ol12 )
cbind( X[ order,],
       SDoutf(X, h=FALSE)[order],
       SDoutf(X, h=TRUE)[order] )
################################################################

################################################################
### Define a weight function "weight()" described on page 533
### see also Stahel, 1981; Donoho 1982
weight = function( rXmax.v ){
    c = min( sqrt( qchisq(p=0.5, df=2)), 4)
    condition = (rXmax.v <= c)
    rXmax.v[condition] = 1
    rXmax.v[!condition] = c/rXmax.v[!condition]^2
    rXmax.v
}
################################################################

################################################################
### 1. Generate 2 data matrices X with different levels of
###    contamination. Use these to generate Fig. 1 - 12

### LOW contamination in X
Xlow = dataX( n=50, nc1=7, nc2=7, nc12=3 )
### Check counts and order of outliers in data matrix X in Xlist
X = Xlow$X; ol1 = Xlow$ol1; ol2 = Xlow$ol2; ol12 = Xlow$ol12;
clean = Xlow$clean
X[ c( clean, ol1, ol2, ol12 ),]

### HIGH contamination in X
Xhigh = dataX( n=50, nc1=13, nc2=13, nc12=7 )
### Check counts and order of outliers in data matrix X in Xlist
X = Xhigh$X; ol1 = Xhigh$ol1; ol2 = Xhigh$ol2; ol12 = Xhigh$ol12
clean = Xhigh$clean
X[ c( clean, ol1, ol2, ol12 ),]
################################################################

################################################################
### 1.2 Create the figures depicting the SD-outlyingness, the
### corresponding weights and the directional outlingness in
### directions (0,1) and (1,1):

### For the first 4 Figures 2 a), b) and 3 a), b) set
h = FALSE # do not use huberized outlyingness
X = Xlow$X; ol1 = Xlow$ol1; ol2 = Xlow$ol2
           ol12 = Xlow$ol12;
file.name = "2LN.png"
main = "SD"
xlab1="Figure 2 a)"; xlab2="Figure 2 b)"
xlab3="Figure 3 a)"; xlab4="Figure 3 b)"
ylab1="Outlyingness"; ylab2="Weights"
ylab3="Outlyingness in [1,0]"; ylab4="Outlyingness in [1,1]"
ylim1=c(0,20); ylim2=c(0,20)
tick1 = 2*(1:10); tick2 = 2*(0:9)

### For the next set of 4 Figures 5 a), b) and 6 a), b) set
h = FALSE # do not use huberized outlyingness
X = Xhigh$X; ol1 = Xhigh$ol1; ol2 = Xhigh$ol2
            ol12 = Xhigh$ol12;
file.name = "2HN.png"
main = "SD"; 
xlab1="Figure 5 a)"; xlab2="Figure 5 b)"
xlab3="Figure 6 a)"; xlab4="Figure 6 b)"
ylab1="Outlyingness"; ylab2="Weights"
ylab3="Outlyingness in [1,0]"; ylab4="Outlyingness in [1,1]"
ylim1=c(0,12); ylim2=c(0,9)
tick1 = 2*(1:6); tick2 = (0:9)

### For the next set of 4 Figures 8 a), b) and 9 a), b) set
h = TRUE # use huberized outlyingness
X = Xlow$X; ol1 = Xlow$ol1; ol2 = Xlow$ol2
           ol12 = Xlow$ol12;
file.name = "2LH.png"
main = "HuSD"
xlab1="Figure 8 a)"; xlab2="Figure 8 b)"
xlab3="Figure 9 a)"; xlab4="Figure 9 b)"
ylab1="Huberized Outlyingness"; ylab2="Huberized Weights"
ylab3="Huberized Outlyingness in [1,0]"
ylab4="Huberized Outlyingness in [1,1]"
ylim1=c(0,20); ylim2=c(0,20)
tick1 = 2*(1:10); tick2 = 2*(0:9)

### For the next set of 4 Figures 11 a), b) and 12 a), b) set
h = TRUE # use huberized outlyingness
X = Xhigh$X; ol1 = Xhigh$ol1; ol2 = Xhigh$ol2
            ol12 = Xhigh$ol12;
file.name = "2HH.png"
main = "HuSD"
xlab1="Figure 11 a)"; xlab2="Figure 11 b)"
xlab3="Figure 12 a)"; xlab4="Figure 12 b)"
ylab1="Huberized Outlyingness"; ylab2="Huberized Weights"
ylab3="Huberized Outlyingness in [1,0]"
ylab4="Huberized Outlyingness in [1,1]"
ylim1=c(0,12); ylim2=c(0,9)
tick1 = 2*(1:6); tick2 = (0:9)
################################################################

################################################################
### ONLY AFTER CHOOSING ONE OF THE 4 SCENARIOS above (e.g.: Low
### contamination with huberized outlyingess) RUN THE
### FOLLOWING:

png(file = file.name, width = 800, height = 400)
par( mfrow=c(1,2) )
### Figure 2: calculate SD-oulyingness over various random
### directions "a":
SDout = SDoutf( X, h=h )
#rXmax = SDout( X, h=h )
### Figure 2, 5, 8, 11 a): plot SD-oulyingness "rXmax":
plot( x=(1:50), y=SDout, pch=4, main=main, xlab=xlab1,
     ylab=ylab1, xaxt="n", yaxt="n", ylim=ylim1)
points( x=ol1, y=SDout[ol1], pch=1, cex=1.5 )
points( x=ol2, y=SDout[ol2], pch=2, cex=1.5  )
points( x=ol12, y=SDout[ol12], pch=0, cex=1.5  )
axis( 1, at=10*(0:5), tcl=0.5 )
axis( 2, at=tick1, tcl=0.5 )

### Figure 2, 5, 8, 11 b): weights based on SD-oulyingness
### using "weight()"
weights = weight( SDout )
plot( x=(1:50), y=weights, pch=4, main=main, xlab=xlab2,
     ylab=ylab2, xaxt="n", yaxt="n")
points( x=ol1, y=weights[ol1], pch=1, cex=1.5 )
points( x=ol2, y=weights[ol2], pch=2, cex=1.5  )
points( x=ol12, y=weights[ol12], pch=0, cex=1.5  )
axis( 1, at=10*(0:5), tcl=0.5 )
axis( 2, at=0.1*(0:10), tcl=0.5 )
dev.off()

png(file = file.name, width = 800, height = 400)
par( mfrow=c(1,2) )
### Figure 3, 6, 9 12 a): directional oulyingness for
### direction (1,0):
rX1 = rXa( X, c(1,0), h=h )
plot( x=(1:50), y=rX1, pch=4, main=main, xlab=xlab3,
     ylab=ylab3, xaxt="n", yaxt="n", ylim=ylim2)
points( x=ol1, y=rX1[ol1], pch=1, cex=1.5 )
points( x=ol2, y=rX1[ol2], pch=2, cex=1.5  )
points( x=ol12, y=rX1[ol12], pch=0, cex=1.5  )
axis( 1, at=10*(0:5), tcl=0.5 )
axis( 2, at=tick2, tcl=0.5 )

### Figure 3, 6, 9, 12 b): directional oulyingness for
### direction (1,1):
rX12 = rXa( X, c(1,1)/sqrt(2), h=h )
plot( x=(1:50), y=rX12, pch=4, main=main, xlab=xlab4,
     ylab=ylab4, xaxt="n", yaxt="n", ylim=ylim2)
points( x=ol1, y=rX12[ol1], pch=1, cex=1.5 )
points( x=ol2, y=rX12[ol2], pch=2, cex=1.5  )
points( x=ol12, y=rX12[ol12], pch=0, cex=1.5  )
axis( 1, at=10*(0:5), tcl=0.5 )
axis( 2, at=tick2, tcl=0.5 )
dev.off()
################################################################

################################################################
### PART 2 - END
################################################################
