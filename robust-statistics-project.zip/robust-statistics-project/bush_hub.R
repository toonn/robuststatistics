library(robustbase)
library(rrcov)
library(MASS)
library(stats)

data(bushfire)
bushfire<-as.matrix(bushfire)

n<-38
p<-5

#modified MAD
mad_adj<-function(x,p)
{
  abs<-abs(x-median(x))
  sorted<-sort(abs)
  m<-length(x)
  mad_adj<-(sorted[ceiling((m+p-1)/2)]
            +sorted[floor((m+p-1)/2+1)])/(2*qnorm(0.5*((m+p-1)/(2*m)+1)))
  return(mad_adj)
}


rbush<-matrix(NA,nrow=n,ncol=p)

for (i in 1:n)
{
  for (j in 1:p)
  {
    rbush[i,j]<-
      abs(bushfire[i,j]-median(bushfire[,j]))/mad_adj(bushfire[,j],p)
  }  
}


#huberize the observations

CH<-qnorm(0.975)
c<-matrix(NA,nrow=n,ncol=p)
bush_hub<-matrix(NA,nrow=n,ncol=p)
for (i in 1:n)
{
  for (j in 1:p)
  {
    c[i,j]<-(bushfire[i,j]-median(bushfire[,j]))/mad(bushfire[,j])
    if (c[i,j]<(-CH)) {bush_hub[i,j]
                       <-median(bushfire[,j])-CH*mad(bushfire[,j])}
    else if (c[i,j]>CH) {bush_hub[i,j]
                         <-median(bushfire[,j])+CH*mad(bushfire[,j])} 
    else bush_hub[i,j]<-bushfire[i,j]
  }
}

#compute the outlyingness on each component of the huberized data
rbush_hub<-matrix(NA,nrow=n,ncol=p)
for (i in 1:n)
{
  for (j in 1:p)
  {
    rbush_hub[i,j]
    <-abs(bush_hub[i,j]-median(bush_hub[,j]))/mad_adj(bush_hub[,j],p)
  }  
}



#generate the finite set of directions

N<-1000

direct<-matrix(NA,ncol=p,nrow=N)

for (i in 1:N) 
{ 
  #sample a subset of size p from original data set
  s<-sample(1:38,p)
  sim1<-bush_hub[s,]
  sim2<-matrix(NA,nrow=p-1,ncol=p)
  for (j in 1:p-1)
  {
    sim2[j,]<-sim1[j,]-sim1[p,]
  }
  #looking for the direction orthogonal to the hyperplane 
  #containing the p sampled observations
  if (rankMM(sim2)==4) direct[i,]<-Null(t(sim2))
}


direct2<-na.omit(direct)
N2<-length(direct2[,1])

#project the data onto the generated directions

SD_proj<-matrix(NA,nrow=n,ncol=N2)

for (i in 1:n)
{
  for (j in 1:N2)
  {
    SD_proj[i,j]<-bushfire[i,]%*%direct2[j,]
  }  
}

HSD_proj<-matrix(NA,nrow=n,ncol=N2)

for (i in 1:n)
{
  for (j in 1:N2)
  {
    HSD_proj[i,j]<-bush_hub[i,]%*%direct2[j,]
  }  
}
#Compute the projected observations on all the generated directions




#compute the outlyingness and relative weights of the projected data

out_proj<-function(A,n_obs,n_d,p)
{
  r_obs<-matrix(NA,nrow=n_obs,ncol=n_d)
  r_max<-rep(NA,n_obs)
  weight<-rep(NA,n_obs)
  cutoff<-min(qchisq(0.5,p),4)
  for (i in 1:n_obs)
  {
    for (j in 1:n_d)
    {
      r_obs[i,j]<-abs(A[i,j]-median(A[,j]))/mad_adj(A[,j],p)
    }
    r_max[i]<-max(r_obs[i,])
    weight[i]
    <-sign(r_max[i]<=cutoff)+((cutoff/r_max[i])^2)*sign(r_max[i]>cutoff)
  }  
  result<-list(r_max,weight)
  return(result)
}

SD_out<-out_proj(SD_proj,n,N2,p)
HSD_out<-out_proj(HSD_proj,n,N2,p)

r_SD<-SD_out[[1]]
r_HSD<-HSD_out[[1]]
w_SD<-SD_out[[2]]
w_HSD<-HSD_out[[2]]


#compute the SD and HSD estimators
T_SD<-(w_SD%*%bushfire)/sum(w_SD)
T_HSD<-(w_HSD%*%bush_hub)/sum(w_HSD)

S_mat<-function(A,M,W,n,p)
{
  prod<-array(0,dim=c(n,p,p))
  for (i in 1:n)
  {
    prod[i,,]<- W[i]*crossprod((A[i,]-M),(A[i,]-M))
  }  
  S_mat<-matrix(NA,nrow=p,ncol=p)
  for (j in 1:p)
  {
    for (k in 1:p)
    {
      S_mat[j,k]<-sum(prod[,j,k])/sum(W)
    }
  }
  return(S_mat)
}
S_SD<-S_mat(bushfire,T_SD,w_SD,n,p)
S_HSD<-S_mat(bush_hub,T_HSD,w_HSD,n,p)

  
T_SD
T_HSD
S_SD
S_HSD



#Calculate the mahalanobis distance and robust distance
RD<-function(x,m,S)
{
  n<-nrow(x)
  RD<-rep(NA,n)
  for (i in 1:n)
  {
    RD[i]<-((x[i,]-m)%*%(solve(S))%*%t(x[i,]-m))^(1/2)
  }
  RD
}

T_MCD<-t(covMcd(bushfire,alpha=0.5)$center)
S_MCD<-covMcd(bushfire,alpha=0.5)$cov

mean<-t(colMeans(bushfire))
cov<-cov(bushfire)
MD<-RD(bushfire,mean,cov)
RD_SD<-RD(bushfire,T_SD,S_SD)
RD_HSD<-RD(bushfire,T_HSD,S_HSD)
RD_MCD<-RD(bushfire,T_MCD,S_MCD)

#Making plots for analysis

par(mfrow=c(1,1))
pairs(bushfire)
par(mfrow=c(1,3))
boxplot(bushfire,main="bushfire")
boxplot(rbush,ylab="outlyingness",ylim=c(0,3),main="original data")
boxplot(rbush_hub,ylab="outlyingness",ylim=c(0,3),main="huberized data")


chi<-qchisq(0.975,p)^(0.5)
par(mfrow=c(1,1))
plot(MD,RD_HSD,xlab="Mahalanobis Distance",
     ylab="HSD distance",main="Distance-Distance Plot")
abline(h=chi,v=chi)
text(x=c(2.6,2.87,2.34,2.46,3.65,3.56,3.74,3.12,2.55),
     y=c(5,5.5,7,6.5,8,11,11.5,10,12),
     labels=c("31","12","10","11","7","8","9","32","33-38"))

par(mfrow=c(1,1))
a<-(0:37)/37
q<-qchisq(a,p)^(1/2)
y<-sort(RD_HSD)
plot(q,y,main="Chisquare QQ-plot",
     xlab="Square root of the quantiles of the chi-squared distribution",
     ylab="HSD distance")



par(mfrow=c(1,3))
plot(RD_SD,xlab="index",ylab="SD Distance",ylim=c(0,25))
abline(h=chi)
text(x=c(7,6,11,31,35),y=c(6,10,7,5.5,10),
     labels=c("7","8-9","10-11","31","32-38"))

plot(RD_HSD,xlab="index",ylab="HSD Distance",ylim=c(0,25))
abline(h=chi)
text(x=c(7,9,13,13.2,31,35),y=c(8,11.5,7,5.2,6,14),
     labels=c("7","8-9","10-11","12","31","32-38"))

plot(RD_MCD,xlab="index",ylab="MCD Distance",ylim=c(0,25))
abline(h=chi)
text(x=c(7,9,13,12,30,31,35),y=c(8.5,14,9,5,6,11,23),
     labels=c("7","8-9","10-11","12","29-30","31","32-38"))




