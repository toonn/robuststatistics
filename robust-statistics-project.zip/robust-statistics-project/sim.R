library("MASS")
library("rrcov")
library("plyr")
library("Matrix")

#data contamination function
#n=number of samples; e=proportion of contamination; 
#p=number of components; d=number of contaminated components
#cor=whether it is correlated; r=correlation coefficient
#k=outlying distance
con<-function(k,e,r){
  r_cor<-diag(p)
  r_cor[lower.tri(r_cor)]=r
  r_cor[upper.tri(r_cor)]=r
  x<-mvrnorm(n,mu=rep(0,p),Sigma=r_cor)
  for (j in 1:d)
  {
    id<-sample(1:n,e*n,replace=F)
    for (i in id)
    { 
      x[i,j]<-rnorm(1,mean=k/sqrt(d),sd=0.1)
    }
  }
  x
}

#hub function: huberization of observations 
#x=data matrix; c_h=predefined cutoff value
hub<-function(x){
  n<-nrow(x)
  p<-ncol(x)
  c<-matrix(nrow=n,ncol=p)
  for (j in 1:p)
  {
    med=median(x[,j])
    mad=median(abs(x[1:n,j]-med))
    for (i in 1:n)
    {
      c[i,j]=(x[i,j]-med)/mad
      if (c[i,j]<(-c_h))
      {
        x[i,j]=med-c_h*mad
      }else if (c[i,j]>c_h)
      {
        x[i,j]=med+c_h*mad
      }
    }
  }
  x
}

#adjusted mad
mad_adj<-function(x)
{
  abs<-abs(x-median(x))
  sorted<-sort(abs)
  m<-length(x)
  mad_adj<-(sorted[ceiling((m+p-1)/2)]
  +sorted[floor((m+p-1)/2+1)])
  /(2*qnorm(0.5*((m+p-1)/(2*m)+1)))
  return(mad_adj)
}


#SD estimators
SD<-function(x){
  n<-nrow(x)
  proj<-matrix(NA,nrow=n,ncol=N_d)
  for (i in 1:n)
  {
    for (j in 1:N_d)
    {
      proj[i,j]<-x[i,]%*%direct[j,]
    }  
  }
  #compute the Hsd outlyingness and relative weights
  r_obs<-matrix(NA,nrow=n,ncol=N_d)
  rsd<-rep(NA,n)
  weight<-rep(NA,n)
  
  c=min(qchisq(0.5,p),4)
  
  for (i in 1:n)
  {
    for (j in 1:N_d)
    {
      r_obs[i,j]<-abs(proj[i,j]-median(proj[,j]))
      /mad_adj(proj[,j])
    }
    rsd[i]<-max(r_obs[i,])
    weight[i]<-sign(rsd[i]<=c)+((c/rsd[i])^2)*sign(rsd[i]>c)
  }
  
  #compute the sd estimators
  T_sd<-(weight%*%x)/sum(weight)
  T_sd
}

Sys.time()


N=500
p<-10
N_d<-200*p
n=100
d=5
c_h=qnorm(0.975)

sd_6=hsd_6=sd_cor6=hsd_cor6=sd_64=hsd_64
=sd_cor64=hsd_cor64=matrix(nrow=N,ncol=2*p)

#generating random directions

direct<-matrix(NA,nrow=N_d,ncol=p)
for (i in 1:N_d)
{
  X<-mvrnorm(1,mu=rep(0,p),Sigma=diag(p))
  Y<-matrix(rnorm(p*p),ncol=p)
  Z<-qr.Q(qr(Y, LAPACK=TRUE))
  direct[i,]<-(Z%*%X)/det(X%*%X)
}

for (a in 1:N)
{
  #datasets
  x6_20<-con(6,0.1,0)
  x6_35<-con(6,0.2,0)
  xcor6_20<-con(6,0.1,0.9)
  xcor6_35<-con(6,0.2,0.9)
  
  hx6_20<-hub(x6_20)
  hx6_35<-hub(x6_35)
  hxcor6_20<-hub(xcor6_20)
  hxcor6_35<-hub(xcor6_35)
  
  x64_20<-con(64,0.1,0)
  x64_35<-con(64,0.2,0)
  xcor64_20<-con(64,0.1,0.9)
  xcor64_35<-con(64,0.2,0.9)
  
  hx64_20<-hub(x64_20)
  hx64_35<-hub(x64_35)
  hxcor64_20<-hub(xcor64_20)
  hxcor64_35<-hub(xcor64_35)
  
  #absolute sd and hsd estimates 
  
  sd_6[a,1:p]=abs((SD(x6_20)))
  sd_6[a,(p+1):(2*p)]=abs((SD(x6_35)))  
  hsd_6[a,1:p]=abs((SD(hx6_20)))
  hsd_6[a,(p+1):(2*p)]=abs((SD(hx6_35)))
  sd_cor6[a,1:p]=abs((SD(xcor6_20)))
  sd_cor6[a,(p+1):(2*p)]=abs((SD(xcor6_35)))  
  hsd_cor6[a,1:p]=abs((SD(hxcor6_20)))
  hsd_cor6[a,(p+1):(2*p)]=abs((SD(hxcor6_35)))
  
  sd_64[a,1:p]=abs((SD(x64_20)))
  sd_64[a,(p+1):(2*p)]=abs((SD(x64_35)))  
  hsd_64[a,1:p]=abs((SD(hx64_20)))
  hsd_64[a,(p+1):(2*p)]=abs((SD(hx64_35)))
  sd_cor64[a,1:p]=abs((SD(xcor64_20)))
  sd_cor64[a,(p+1):(2*p)]=abs((SD(xcor64_35)))  
  hsd_cor64[a,1:p]=abs((SD(hxcor64_20)))
  hsd_cor64[a,(p+1):(2*p)]=abs((SD(hxcor64_35)))  
}
Sys.time()

#prepare data frame for plots

uncor10_6<-data.frame("SD-NC"=rowMeans(sd_6[,(d+1):p]),
                      "HSD-NC"=rowMeans(hsd_6[,(d+1):p]),
                      "SD-C"=rowMeans(sd_6[,1:d]),
                      "HSD-C"=rowMeans(hsd_6[,1:d]))

uncor20_6<-data.frame("SD-NC"=rowMeans(sd_6[,(p+d+1):(2*p)]),
                      "HSD-NC"=rowMeans(hsd_6[,(p+d+1):(2*p)]),
                      "SD-C"=rowMeans(sd_6[,(p+1):(p+d)]),
                      "HSD-C"=rowMeans(hsd_6[,(p+1):(p+d)]))

cor10_6<-data.frame("SD-NC"=rowMeans(sd_cor6[,(d+1):p]),
                    "HSD-NC"=rowMeans(hsd_cor6[,(d+1):p]),
                    "SD-C"=rowMeans(sd_cor6[,1:d]),
                    "HSD-C"=rowMeans(hsd_cor6[,1:d]))

cor20_6<-data.frame("SD-NC"=rowMeans(sd_cor6[,(p+d+1):(2*p)]),
                    "HSD-NC"=rowMeans(hsd_cor6[,(p+d+1):(2*p)]),
                    "SD-C"=rowMeans(sd_cor6[,(p+1):(p+d)]),
                    "HSD-C"=rowMeans(hsd_cor6[,(p+1):(p+d)]))

uncor10_64<-data.frame("SD-NC"=rowMeans(sd_64[,(d+1):p]),
                       "HSD-NC"=rowMeans(hsd_64[,(d+1):p]),
                       "SD-C"=rowMeans(sd_64[,1:d]),
                       "HSD-C"=rowMeans(hsd_64[,1:d]))

uncor20_64<-data.frame("SD-NC"=rowMeans(sd_64[,(p+d+1):(2*p)]),
                       "HSD-NC"=rowMeans(hsd_64[,(p+d+1):(2*p)]),
                       "SD-C"=rowMeans(sd_64[,(p+1):(p+d)]),
                       "HSD-C"=rowMeans(hsd_64[,(p+1):(p+d)]))

cor10_64<-data.frame("SD-NC"=rowMeans(sd_cor64[,(d+1):p]),
                     "HSD-NC"=rowMeans(hsd_cor64[,(d+1):p]),
                     "SD-C"=rowMeans(sd_cor64[,1:d]),
                     "HSD-C"=rowMeans(hsd_cor64[,1:d]))

cor20_64<-data.frame("SD-NC"=rowMeans(sd_cor64[,(p+d+1):(2*p)]),
                     "HSD-NC"=rowMeans(hsd_cor64[,(p+d+1):(2*p)]),
                     "SD-C"=rowMeans(sd_cor64[,(p+1):(p+d)]),
                     "HSD-C"=rowMeans(hsd_cor64[,(p+1):(p+d)]))

#boxplots
par(mfrow=c(2,4))
boxplot(uncor10_6,ylab="absolute errors",ylim=c(0,1),main="k=6",las=2)
boxplot(uncor10_64,ylab="absolute errors",ylim=c(0,1),main="k=64",las=2)
boxplot(cor10_6,ylab="absolute errors",ylim=c(0,1),main="k=6",las=2)
boxplot(cor10_64,ylab="absolute errors",ylim=c(0,1),main="k=64",las=2)
boxplot(uncor20_6,ylab="absolute errors",ylim=c(0,1),main="k=6",las=2)
boxplot(uncor20_64,ylab="absolute errors",ylim=c(0,3),main="k=64",las=2)
boxplot(cor20_6,ylab="absolute errors",ylim=c(0,1),main="k=6",las=2)
boxplot(cor20_64,ylab="absolute errors",ylim=c(0,3),main="k=64",las=2)